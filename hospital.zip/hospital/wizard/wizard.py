from odoo import models,fields,api,_

class Wizard(models.TransientModel):
    _name = 'hospital.wizard'
    _description = 'Wizard Descripion'

    patient_id = fields.Many2one('hospital.patient',string = 'Patient')
    appointment = fields.Many2many('hospital.appointment')

    def create_appointment(self):
        return {
            'name': _('Test Wizard'),
            'domain': [],
            'res_model': 'hospital.appointment', # go to the model patient after create the wizard
            'view_type': 'form',
            'view_id': False,
            'view_mode': 'tree,form',
            'type': 'ir.actions.act_window',
        }
