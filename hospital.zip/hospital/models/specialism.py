from odoo import models,fields,api,_
import odoo.exceptions

class Specialism(models.Model):
    _name = 'hospital.specialism'
    _description = 'specialisms'

    name = fields.Char('Availble Specialisms')
    # doctor_id = fields.One2many('res.users','special',string = 'Specialized Doctor')
    patient_ids = fields.One2many('hospital.patient','diagnose_id',string="Related Patients")
    medicine_id = fields.Many2many('hospital.medicine')
    _sql_constraints = [
        ('name_uniq', 'unique (name)', "Special name already exists !"),
    ]
    # @api.constrains('name')
    # def _check_doctors_special(self):
    #     for rec in self:
    #         if rec.env['hospital.doctor'].search([('specialism_id', '!=', rec.name)]):
    #             raise odoo.exceptions.ValidationError(_('This pateint is not valid'))


    def delete_selected_values(self):
        for rec in self:
            rec.medicine_id = [(5,0,0)]