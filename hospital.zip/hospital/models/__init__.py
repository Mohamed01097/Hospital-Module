# -*- coding: utf-8 -*-

from . import models
from . import patient
from . import doctor
from . import specialism
from . import appointment
from . import create_from_outside
from . import inherit
from . import medicine
