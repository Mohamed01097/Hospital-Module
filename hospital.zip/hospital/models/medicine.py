from odoo import models,fields,api,_
import odoo.exceptions

class Medicine(models.Model):
    _name = 'hospital.medicine'
    _description = 'medicines'

    name = fields.Char()
    specialism_id = fields.Char()