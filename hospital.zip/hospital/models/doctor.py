from odoo import models,fields,api,_
import odoo.exceptions
import random


class Doctor(models.Model):
    _name = 'hospital.doctor'
    _description = 'Doctors'
    _rec_name = 'name_id'

    name_id = fields.Many2one('res.partner', string = 'Doctor Name')
    active = fields.Boolean(default = True)
    specialism_id = fields.Many2one("hospital.specialism", string="Specialism")
    random_variable = random.randint(0, 1000000)
    res = lambda number: number
    contact = fields.Char('Contact Number', required=True, default = '02'+str(res(random_variable)))
    notes = fields.Text('Notes About Case')
    appointment_ids = fields.Many2many('hospital.appointment','doctor_id')
    state = fields.Selection([
        ('draft', 'Draft'),
        ('done', 'Done'),
        # ('cancel', 'Cancelled'),
        ('confirm', 'Confirmed')
    ], 'Status', default='draft', index=True, required=True, readonly=True, copy=False)
    gender = fields.Selection([('male','Male'),('female','Female')])
    _sql_constraints = [
        ('name_id', 'unique (name_id)', 'This doctor is already existed in another specailist')
    ]

    _sql_constraints = [
        ('appointment_ids', 'unique (appointment_ids)', 'This appointment is already reserved ')
    ]

    def action_done(self):
        for rec in self:
            rec.state = 'done'

    def action_confirm(self):
        for rec in self:
            rec.state =  'confirm'

    @api.constrains('contact')
    def _check_nationality(self):
        if self.contact.startswith('02') == False:
            raise exceptions.ValidationError(_('Doctor Must Be Egyptian'))



    # def name_get(self):
    #     res = []
    #     for rec in self:
    #         name = (rec.name_id)
    #         res +=  name
    #     print(res)
