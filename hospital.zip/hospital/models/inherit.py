from odoo import models,fields,api,_

class ResPartner(models.Model):
    _inherit = 'res.partner'

    company_type = fields.Selection(selection_add=[('hos', 'odoo dev'),('company',)], tracking=True, ondelete={'hos':'cascade'})

# class HrEmpolyee(models.Model):
#     _inherit = 'hr.empolyee'
#
#     resource_calendar_id = fields.Selection(selection_add=[('new', 'Standard 45 hours/week'),('Standard 40 hours/week',)], tracking=True, ondelete={'hos':'cascade'})