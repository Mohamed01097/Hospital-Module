import datetime
from odoo import models,fields,api,_

class school_management(models.Model):
    _name = 'hospital.student'
    _inherit = 'hr.employee'

    special = fields.Many2one("hospital.specialism")
    # define new relation name and better column names
    # and I think you need a new category model because this one is used for employee category, may be it's better to create hr.student.category table I don't know it's up to you
    category_ids = fields.Many2many(
      'hr.employee.category', 'student_category_rel',
      'student_id', 'category_id',
      string='Tags')
