from odoo import models,fields,api,_
from odoo.exceptions import ValidationError
import random,datetime

class Patient(models.Model):
    _name = 'hospital.patient'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Patients'
    _rec_name = 'name'
    _order = 'diagnose_id desc'

    name = fields.Char(string = 'Patient Name')
    age = fields.Integer(string = 'Patient Age')
    gender = fields.Selection([
        ('male','Male'),
        ('female','Female')
    ])

    group = fields.Selection([
        ('major', 'Major'),
        ('minor', 'Minor')
    ],compute = 'set_group',store=True)

    random_variable = random.randint(0,1000000)
    res = lambda number: number
    contact = fields.Char('Contact Number',required = True,default = str(res(random_variable)))
    notes = fields.Text('Notes About Case')
    diagnose_id = fields.Many2one('hospital.specialism')
    doctor_id = fields.Many2one('hospital.doctor',string = 'Related Doctor')
    appointment_id = fields.Many2one('hospital.appointment','Related Appointment')
    start_date = fields.Date(default=datetime.date.today())
    duration = fields.Float('Duration')
    user_id = fields.Many2one('res.users', 'Pro')
    email_id = fields.Char('Email',compute='set_email',store=True)
    num_patients = fields.Integer(compute='_count_patients',store=True,string='Number Of Patients')
    doctor_gender = fields.Selection([
        ('male', 'Male'),
        ('female', 'Female')
    ],related ='gender' )
    secuence = fields.Char(string='Patient_ID', required=True, copy=False,
                           readonly=True, index=True, default=lambda self: _('New'))
    image_1920 = fields.Image("Image 1024", max_width=1920, max_height=1920, store=True)
    _sql_constraints = [
        ('name_uniq', 'UNIQUE (name)', 'This patient is already exist!')
    ]
    def open_doctors_related(self):
        return {
            'name': _('Doctors'),
            'domain': [],
            'res_model': 'hospital.doctor',
            'view_type':'form',
            'view_id':False,
            'view_mode':'tree,form',
            'type': 'ir.actions.act_window',
        }
    @api.model
    def create(self, vals):
        if vals.get('secuence', _('New')) == _('New'):
            vals['secuence'] = self.env['ir.sequence'].next_by_code('hospital.patient.secuence') or _('New')
        result = super(Patient, self).create(vals)
        return result

    @api.constrains('contact')
    def _check_patient_country(self):
        if len(str(self.contact)) <6:
            raise ValidationError(_('contact invalid data'))

    @api.depends('age')
    def set_group(self):
        for rec in self:
            if rec.age < 20:
                self.group = 'major'
                continue
            self.group = 'minor'

    def action_patients(self):
        return {
            'name': _('Patients Server Action'),
            'domain': [],
            'res_model':'hospital.patient',
            'view_type':'form',
            'view_id': False,
            'view_mode':'tree,form',
            'type':'ir.actions.act_window',
        }

    def action_send_email(self):
        template_id = self.env.ref('hospital.mail_template_pateint_card').id
        template = self.env['mail.template'].browse(template_id)
        template.send_mail(self.id,force_send=True)

    @api.constrains('name')
    def check_patient(self):
        for rec in self:
            if rec.env['hospital.doctor'].search(['|','|',('name_id', '=', rec.name.upper()),('name_id', '=', rec.name.lower()),('name_id', '=', rec.name.title())]):
                raise ValidationError(_('The doctor musnt be the pateint'))

    @api.depends('name')
    def set_email(self):
        for rec in self:
            if rec.name:
                rec.email_id = rec.name+"@gmail.com"
            else:
                continue

    @api.depends('name')
    def _count_patients(self):
        self.num_patients = self.search_count([])
