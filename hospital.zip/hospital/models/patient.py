from odoo import models,fields,api,_
from odoo.exceptions import ValidationError
import random,datetime

class Patient(models.Model):
    _name = 'hospital.patient'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Patients'
    _rec_name = 'name'
    _order = 'diagnose_id desc'

    # def set_default_contact(self):
    #     self.contact = random.randint(0,1000000)
    name = fields.Char(string = 'Patient Name')
    age = fields.Integer(string = 'Patient Age')
    gender = fields.Selection([
        ('male','Male'),
        ('female','Female')
    ])

    group = fields.Selection([
        ('major', 'Major'),
        ('minor', 'Minor')
    ],compute = 'set_group',store=True)

    random_variable = random.randint(0,1000000)
    res = lambda number: number
    contact = fields.Char('Contact Number',required = True,default = str(res(random_variable)))
    notes = fields.Text('Notes About Case')
    diagnose_id = fields.Many2one('hospital.specialism')
    doctor_id = fields.Many2one('hospital.doctor',string = 'Related Doctor')
    appointment_id = fields.Many2one('hospital.appointment','Related Appointment')
    start_date = fields.Date(default=datetime.date.today())
    duration = fields.Float('Duration')
    user_id = fields.Many2one('res.users', 'Pro')
    email_id = fields.Char('Email')
    # end_date = fields.Date(string="End Date",compute='_get_end_date',inverse='_set_end_date',store=True)

    doctor_gender = fields.Selection([
        ('male', 'Male'),
        ('female', 'Female')
    ],compute = '_prevent_mixing')
    secuence = fields.Char(string='Patient_ID', required=True, copy=False,
                           readonly=True, index=True, default=lambda self: _('New'))
    image_1920 = fields.Image("Image 1024", max_width=1920, max_height=1920, store=True)
    # patient_name_upper = fields.Char(compute='compute_upper_name',inverse = 'compute_lower_name',string='Upper Name')

    _sql_constraints = [
        ('name_uniq', 'UNIQUE (name)', 'This patient is already exist!')
    ]
    # @api.depends('name')
    # def compute_upper_name(self):
    #     for rec in self:
    #         rec.patient_name_upper = rec.name.upper() if rec.name else False
    #
    # def compute_lower_name(self):                           # difference between self and rec(loop)
    #     for rec in self:
    #         rec.name = rec.patient_name_upper.lower() if rec.patient_name_upper else False


    def open_doctors_related(self):
        return {
            'name': _('Doctors'),
            'domain': [],
            'res_model': 'hospital.doctor',
            'view_type':'form',
            'view_id':False,
            'view_mode':'tree,form',
            'type': 'ir.actions.act_window',
        }
    @api.model
    def create(self, vals):
        if vals.get('secuence', _('New')) == _('New'):
            vals['secuence'] = self.env['ir.sequence'].next_by_code('hospital.patient.secuence') or _('New')
        result = super(Patient, self).create(vals)
        return result

    # @api.onchange('doctor_id')
    # def set_doctor_gender(self):
    #     if self.doctor_id:
    #         self.doctor_gender = self.doctor_id.gender

    @api.constrains('contact')
    def _check_patient_country(self):
        if len(str(self.contact)) <6:
            raise ValidationError(_('contact invalid data'))

    @api.depends('gender')
    def _prevent_mixing(self):
        self.doctor_gender = self.gender

    @api.depends('age')
    def set_group(self):
        for rec in self:
            if rec.age < 20:
                self.group = 'major'
                continue
            self.group = 'minor'

    def action_patients(self):
        return {
            'name': _('Patients Server Action'),
            'domain': [],
            'res_model':'hospital.patient',
            'view_type':'form',
            'view_id': False,
            'view_mode':'tree,form',
            'type':'ir.actions.act_window',
        }
    # @api.depends('start_date','duration')
    # def _get_end_date(self):
    #     if self.duration ==0.0:
    #         self.end_date = self.start_date
    #     duration = datetime.timedelta(days= self.duration,seconds=-1)
    #     self.end_date = self.start_date + duration

    # def _set_end_date(self):
    #     for rec in self:
    #     rec.duration = (rec.end_date - rec.start_date).days+1
    def action_send_email(self):
        template_id = self.env.ref('hospital.mail_template_pateint_card').id
        template = self.env['mail.template'].browse(template_id)
        template.send_mail(self.id,force_send=True)

    def test_corn_patient(self):
        pass

    @api.constrains('name')
    def check_patient(self):
        for rec in self:
            if rec.env['hospital.doctor'].search(['|','|',('name_id', '=', rec.name.upper()),('name_id', '=', rec.name.lower()),('name_id', '=', rec.name.title())]):
                raise ValidationError(_('The doctor musnt be the pateint'))

