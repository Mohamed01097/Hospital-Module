import datetime

from odoo import models,fields,api,_

class Appointment(models.Model):
    _name = 'hospital.appointment'
    # _inherits = {'hospital.patient': 'num_patients'}
    _description = 'appointments'
    _rec_name = 'appointment'

    appointment = fields.Date(string ='Appointments')
    start_date = fields.Date(default= datetime.date.today())
    patient_id = fields.Many2one('hospital.patient')
    doctor_id = fields.Many2one('hospital.doctor')
    num_patient = fields.Integer(string= 'Number Of patients',related='patient_id.num_patients',readonly=True)
    num_doctor = fields.Integer(string= 'Number Of doctors',related='doctor_id.num_doctors',readonly=True)
    performance = fields.Float(compute='_set_performance_work',store=True,string="Performance")
    def open_doctor_appoiontment(self):
        return {
            'name': _('Doctors'),
            'type': 'ir.actions.act_window',
            'res_model': 'hospital.doctor',
            'view_id': False,
            'view_mode': 'tree,form',
            'view_type': 'form',
            'domain':[('name_id','=','self.id')]
        }

    @api.depends('patient_id','doctor_id')
    def _set_performance_work(self):
        for rec in self:
            if not rec.num_doctor or not rec.num_patient:
                rec.performance = 0.0
            else:
                rec.performance = (rec.num_doctor/rec.num_patient)*100.0

    @api.onchange('doctor_id')
    def onchange_doctor_id(self):
        for rec in self:
            return{'domain':{'patient_id':[('doctor_id','=',rec.doctor_id.id)]}}