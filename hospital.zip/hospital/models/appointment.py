import datetime

from odoo import models,fields,api,_

class Appointment(models.Model):
    _name = 'hospital.appointment'
    _description = 'appointments'
    _rec_name = 'appointment'

    appointment = fields.Date(string ='Appointments')
    start_date = fields.Date(default= datetime.date.today())
    patient_id = fields.Many2one('hospital.patient')
    doctor_id = fields.Many2one('hospital.doctor')
    def open_doctor_appoiontment(self):
        return {
            'name': _('Doctors'),
            'type': 'ir.actions.act_window',
            'res_model': 'hospital.doctor',
            'view_id': False,
            'view_mode': 'tree,form',
            'view_type': 'form',
            'domain':[('name_id','=','self.id')]
        }


    # _sql_constraints = [
    #     ('appointment_uniq', 'unique (appointment)', "This appointment already reserved!"),
    #     ('patient_uniq', 'unique (patient_id)', "Some thing went wrong"),
    #     ('appointment_uniq', 'unique (doctor_id)', "Some thing went wrong"),
    # ]

